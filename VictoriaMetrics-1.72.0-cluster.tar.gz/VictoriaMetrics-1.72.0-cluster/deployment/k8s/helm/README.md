### Helm chart has been moved to [helm-chart](https://github.com/VictoriaMetrics/helm-charts) repository.  
