`vmstorage` performs the following tasks:

- Accepts inserts from `vminsert` nodes and stores them to local storage.

- Performs select requests from `vmselect` nodes.
