`vminsert` routes the ingested data to `vmstorage`.
