package consts

// MaxInsertPacketSize is the maximum packet size in bytes vminsert may send to vmstorage.
const MaxInsertPacketSize = 100 * 1024 * 1024
